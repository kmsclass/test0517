package test;

public interface ArticleDao {
	void insert(String str)  throws Exception; 
	void update(String str)  throws Exception; 
	void delete(String str)  throws Exception; 
}
